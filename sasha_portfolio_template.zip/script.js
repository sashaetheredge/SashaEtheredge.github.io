// This file is intentionally simple.
// The site works without JavaScript.
// You can add interactive features here later if you want them.
