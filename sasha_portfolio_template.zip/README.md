# Editable Portfolio Website Template

This is a starter portfolio website for a college mass communication student.

## Files
- index.html = the website content
- style.css = the design and layout
- script.js = optional JavaScript
- README.md = these instructions

## How to edit
Open `index.html` in a text/code editor and replace anything in [BRACKETS] with your information.

To add your photo:
1. Put your image file in the same folder as `index.html`.
2. Replace the `photo-placeholder` section in `index.html` with:
   `<img class="profile-photo" src="your-photo.jpg" alt="Professional photo of Your Name">`
3. Add `.profile-photo { width: 100%; height: 500px; object-fit: cover; }` to `style.css`.

For work samples, you can replace the placeholder boxes with images, embedded media, or links to your projects.

## Publishing with GitHub Pages
1. Create/sign into a GitHub account.
2. Create a new public repository.
3. Upload `index.html`, `style.css`, and `script.js`.
4. In the repository, open Settings > Pages.
5. Choose GitHub Actions or the branch-based Pages option available in your account.
6. Publish the site.
7. GitHub will give you a public website address.

Note: The included contact form is a visual template. GitHub Pages does not process form submissions by itself. Before submitting the site, connect the form to a form service or use a professional email link instead.
